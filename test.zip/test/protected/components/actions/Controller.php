<?php
class Controller extends CAction{
	/**
	public static function actions()
	{
		return array (
				// naming the action and pointing to the location
				// where the external action class is
				'GetDate' => 'application.components.breadCrumb.Widget',
		);
	
	}*/
	public function run(){
		echo 'HELLO WORLD';
	}
}